version: 

tools.jar: 1.6.0_20